// Copyright (C) 2023 Actia Nordic AB. All rights reserved.

#include <stdio.h>

int main(void)
{
    printf("Hello ACU6 User\n");

    return 0;
}
